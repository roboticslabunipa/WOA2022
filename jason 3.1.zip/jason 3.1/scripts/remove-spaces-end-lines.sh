find . -name "*.java" -exec sed -i "" 's/[[:space:]]*$//' {} \;
