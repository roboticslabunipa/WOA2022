package jason.util;

import java.io.Serializable;

public interface RunnableSerializable extends Runnable, Serializable {

}
