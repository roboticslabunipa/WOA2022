package jason.environment;

/**
 * @deprecated this class was renamed to TimeSteppedEnvironment
 */
@Deprecated
public class SteppedEnvironment extends TimeSteppedEnvironment {
}
