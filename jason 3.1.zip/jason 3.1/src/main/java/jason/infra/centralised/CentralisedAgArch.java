package jason.infra.centralised;

import jason.infra.local.LocalAgArch;

/**
 * @deprecated use LocalAgAarch instead
 */
@Deprecated
public class CentralisedAgArch extends LocalAgArch {
}
