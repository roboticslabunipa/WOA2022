package jason.asunit;

public interface Condition {
    public boolean test(TestArch arch);
}
